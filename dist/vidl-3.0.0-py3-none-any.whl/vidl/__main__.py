if __name__ == '__main__':
    from vidl import app
    app.main()