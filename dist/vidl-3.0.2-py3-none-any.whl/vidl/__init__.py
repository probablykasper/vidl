from vidl import app
def main():
    return app.main()